EVRP.cpp EVRP.hpp
Implementation of the electric vehicle routing. 
The parameters and functions in this class can be used in the implementation of your solver

stats.cpp stats.hpp
Implementation to store the best solution for the 20 RUNS. 
The functions in this class can be used in your implementation to generate the 
required results of your solver in output text files

heuristic.cpp heuristic.hpp
Sample code of a heuristic that generates a solution randomly
Suggestion: to implement your solver here.

main.cpp 
Executable of the source code